<?php

namespace Home\Controller;

use Think\Controller;

class IndexController extends Controller
{

    public function index()
    {
    	header('Content-Type:text/html;charset=utf-8');
    	$app_id = I('app_id', 0, 'intval');

    	if (M('app')->where(array('id' => $app_id))->getField('status') != 1) {
    		exit( '项目接口不存在或被禁止访问！' );
    	}

        $Face = M('face');

        $map = array('app_id' => $app_id, 'status' => 1, 'pid' => 0);
        $field = array(
            'id', 'pid', 'method', 'title'
        );
    	$list = $Face->field($field)->where($map)->select();

        foreach ($list as $key => $val) {
            $map['pid'] = $val['id'];
            $list[$key]['_child'] = $Face->field($field)->where($map)->select();
        }

        $this->assign('_list', $list);
        $this->display();
    }

    public function right()
    {
        $id = I('id', 0, 'intval');
        $data = M('face')->where(array('id' => $id, 'status' => 1))->find();
        if (!$data) {
            exit( '接口不存在或被禁止访问' );
        }
        $data['data'] = empty($data['data']) ? [] : unserialize($data['data']);

        $this->assign('data', $data);
    	$this->display();
    }

    /**
     * 创建项目目录
     */
    public function addDir()
    {
        if (($app_id = I('app_id', 0, 'intval')) > 0 && ($title = I('title', '', 'trim'))) {
            $data = [
                'pid' => 0,
                'title' => $title,
                'app_id' => $app_id
            ];
            M('face')->add($data);
        }
        $this->redirect('index', array('app_id' => $app_id));
    }

    /**
     * 加载新增/编辑接口的表单
     */
    public function face()
    {
        $this->display();
    }

    /**
     * 新增/编辑接口post数据提交处理
     */
    public function addFace()
    {
        if (IS_POST) {
            if (($id = I('id', 0, 'intval')) == 0) { // 新增
                dump($_POST);
            } else { // 编辑

            }
            die;
            $this->redirect('index', array('app_id' => I('app_id')));
        } else {
            exit( '不支持的请求方式' . $_SERVER['REQUEST_METHOD'] );
        }
    }

    /**
     * 参数表单的HTML
     */
    public function paramTable()
    {
        $this->display();
    }

}